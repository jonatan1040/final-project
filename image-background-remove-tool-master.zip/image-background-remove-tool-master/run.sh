#!/bin/bash
cd bin
python main.py ../input ../output 1
